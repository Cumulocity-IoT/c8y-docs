#!/usr/bin/python
"""
For description and usage information, refer to ./readme.txt 
"""

import argparse
import logging
import os
import subprocess
import sys
import tempfile
import yaml
import re
import requests
from requests.auth import HTTPBasicAuth
from typing import List
from urllib.parse import urlparse

# Setup logging
logging.basicConfig(
    format = "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level = logging.INFO
)
_logger = logging.getLogger(__name__)


_SYNC_COMMAND_DESCRIPTION = 'Synchronize the Cumulocity Edge dependencies from the remote Cumulocity Edge registry to a private registry.'
_SETUP_COMMAND_DESCRIPTION = 'Setup a private registry.'

_EDGE_DEPENDENCIES_FOLDER = 'edge/dependencies'
_DEPENDENCIES_YAML_LOCATION = f'{_EDGE_DEPENDENCIES_FOLDER}/dependencies.yaml'

class RegistrySync(object):
    def __init__(self, *args):
        if not args:
            return

        _logger = logging.getLogger(self.__class__.__name__)

        ## https://chase-seibert.github.io/blog/2014/03/21/python-multilevel-argparse.html
        action_parser = argparse.ArgumentParser(description='Synchronize the Cumulocity Edge dependencies from the remote Cumulocity Edge registry to a private registry.', 
                                                usage=f'''<action> [<args>]
Allowed action is:
    sync     {_SYNC_COMMAND_DESCRIPTION}
''')

        action_parser.add_argument("action", help="Action to perform. sync or setup")

        args = action_parser.parse_args(args[1:2])
        action_function = f"_{args.action}"
        if not hasattr(self, action_function):
            message = f"Unrecognized action '{args.action}"
            _logger.error(message, exc_info=False)

            exit(1)

        # use dispatch pattern to invoke method with same name
        getattr(self, action_function)()

    def _sync(self):
        parser = argparse.ArgumentParser(description=_SYNC_COMMAND_DESCRIPTION)

        parser.add_argument("-v", "--edge-version",
                            help="Cumulocity Edge version (e.g. 1018.0.0)", required=True)
        parser.add_argument("-sr", "--source-registry",
                            help="URI of the Cumulocity Edge registry (e.g. registry.c8y.io)", required=True)
        parser.add_argument("-sru", "--source-registry-username",
                            help="Username to access the Cumulocity Edge registry", required=True)
        parser.add_argument("-srp", "--source-registry-password",
                            help="Password to access the Cumulocity Edge registry", required=True)
        parser.add_argument("-tr", "--target-registry",
                            help="URI of a private registry (hostname/IP Address)", required=True)
        parser.add_argument("-tru", "--target-registry-username",
                            help="Username to access a private registry", required=True)
        parser.add_argument("-trp", "--target-registry-password",
                            help="Password to access a private registry", required=True)
        parser.add_argument("-trt", "--target-registry-type",
                            choices=['HARBOR'],
                            help="Private registry type is specifically needed for creating the required projects in the case of Harbor. Pass 'HARBOR' for Harbor registry.", required=False, default='')
        parser.add_argument("-dr", "--dryrun",
                            help="--dryrun true option, identifies and list the artifacts which would be synced from source registry to target. Defaults to 'false'", required=False, default='false')

        kwargs = vars(parser.parse_args(sys.argv[2:]))
        self.sync(**kwargs)

    def _setup(self):
        parser = argparse.ArgumentParser(description=_SETUP_COMMAND_DESCRIPTION)

        kwargs = vars(parser.parse_args(sys.argv[2:]))
        self.setup(**kwargs)

    def setup(self):

        _logger.info("Action 'setup' is not supported.")
        raise Exception("Action 'setup' is not supported.")

    def _flatten(self, data):
        flattened_dict = {}
        
        for key, value in data.items():
            flattened_dict[key] = dict()
            for subkey, subvalue in value.items():
                if isinstance(subvalue, dict) and "upgrade-paths" in subvalue:
                    flattened_dict[key][subkey] = {k: v for k, v in subvalue.items() if k != "upgrade-paths"}
                    for upgrade_key, upgrade_value in subvalue["upgrade-paths"].items():
                        prefixed_key = f"{upgrade_key}-{subkey}"
                        flattened_dict[key][f"{key}-{prefixed_key}"] = upgrade_value
                else:
                    flattened_dict[key][subkey] = subvalue
 
        return flattened_dict
    
    def sync(self, edge_version, source_registry, source_registry_username, source_registry_password, target_registry, target_registry_username, target_registry_password, target_registry_type='', dryrun='false'):
        if not dryrun:
            # This initialization is necesssary as generate() when invoked using **kwargs 
            # the dryrun default specified in the function signature will not take effect.  
            dryrun = False 
        else:
            dryrun = dryrun.lower() in ['true', '1']

        try:
            _logger.info(f"======= Started copying dependencies of Cumulocity Edge version '{edge_version}' from the source registry '{source_registry}' into the target registry '{target_registry}'.")

            with tempfile.TemporaryDirectory() as tmpDirectory:
                sourceRegistryClient = RegistryClient(source_registry, source_registry_username, source_registry_password, tmpDirectory)
                targetRegistryClient = RegistryClient(target_registry, target_registry_username, target_registry_password, tmpDirectory)
                if target_registry_type.upper() == 'HARBOR':
                    targetRegistryClient.create_harbor_projects(dryrun)

                # Download and read the dependencies.yaml file tagged with 'edge_version', from the source registry
                try:
                    dependencies_file_path = sourceRegistryClient.oras_pull(_DEPENDENCIES_YAML_LOCATION, edge_version, dryrun=False) # Download even when the dryrun flag is set to true
                except:
                    # This could happen when the major version changes after the release 
                    message = f"Couldn't find the Cumulocity Edge version '{edge_version}' in the provided source registry '{source_registry}'."
                    _logger.error(message)
                    raise Exception(message)

                with open(dependencies_file_path, 'r') as dependencies_file:
                    dependencies = yaml.safe_load(dependencies_file)

                # For each component in the dependencies,
                #   download the component from the source registry
                #   upload the same into the target registry
                #   special case: 
                #       the thirdparty components are downloaded from the 
                #       original source, which means the Helm Charts could
                #       be non OCI based (plain http) downloads. 
                _dependencies = self._flatten(dependencies)
                for categoryKey, category in _dependencies.items():
                    for _, component in category.items():
                        # Skip processing if the edge-repository is not present. For handling components 
                        # like pulsar-bookkeeper-journal-storage and pulsar-bookkeeper-ledgers-storage,
                        # which just define the default storage resources and not the artifacts.
                        if 'edge-repository' not in component:
                            continue

                        if categoryKey == 'thirdparty':
                            if component['edge-repository'].startswith("http"):
                                sourceRegistry = urlparse(component['edge-repository']).netloc
                                sourceRepo = component['edge-repository']
                            else:
                                sourceRegistry = component['edge-repository'].split('/', 1)[0]
                                sourceRepo = component['edge-repository'].split('/', 1)[1]

                            if 'original-repository' in component:
                                targetRepo = f"edge-thirdparty/{component['original-repository'].split('/', 1)[1]}"
                            else:
                                targetRepo = f"edge-thirdparty/{component['edge-repository'].split('/', 1)[1]}"

                            thirdpartySourceRegistryClient = RegistryClient(sourceRegistry, None, None, tmpDirectory)

                            if 'chart-name' in component:
                                if sourceRepo.startswith("http"):
                                    chart_file_path = thirdpartySourceRegistryClient.chart_pull_http(sourceRepo, component['chart-name'], component['version'], dryrun=False)
                                else:
                                    chart_file_path = thirdpartySourceRegistryClient.chart_pull(sourceRepo, component['chart-name'], component['version'], dryrun=False)
                                targetRegistryClient.chart_push(chart_file_path, targetRepo, dryrun=dryrun)

                                _logger.info(f"Copied helm chart\t {sourceRegistry}/{sourceRepo}/{component['chart-name']}:{component['version']}")
                            else:
                                component_file_path = thirdpartySourceRegistryClient.docker_pull(sourceRepo, component['version'], dryrun=False)
                                targetRegistryClient.docker_push(component_file_path, targetRepo, component['version'], dryrun=dryrun)

                                _logger.info(f"Copied docker image\t {sourceRegistry}/{sourceRepo}:{component['version']}")

                        elif 'chart-name' in component:
                            chart_version = component['version']
                            if component['chart-name'] == 'cumulocity-iot-edge-operator':
                                chart_version = edge_version
                                if 'edge-repository-oci' in component:
                                    component['edge-repository'] = component['edge-repository-oci']                                
                            
                            chart_file_path = sourceRegistryClient.chart_pull(component['edge-repository'], component['chart-name'], chart_version, dryrun=False)
                            targetRegistryClient.chart_push(chart_file_path, component['edge-repository'], dryrun=dryrun)

                            _logger.info(f"Copied helm chart\t {component['edge-repository']}/{component['chart-name']}:{component['version']}")
                        elif component['edge-repository'].startswith('edge/dependencies/'):
                            oras_file_path = sourceRegistryClient.oras_pull(component['edge-repository'], component['version'], dryrun=False)
                            targetRegistryClient.oras_push(oras_file_path, component['edge-repository'], component['version'], dryrun=dryrun)

                            _logger.info(f"Copied file\t\t {component['edge-repository']}:{component['version']}")
                        else:
                            component_file_path = sourceRegistryClient.docker_pull(component['edge-repository'], component['version'], dryrun=False)
                            targetRegistryClient.docker_push(component_file_path, component['edge-repository'], component['version'], dryrun=dryrun)

                            _logger.info(f"Copied docker image\t {component['edge-repository']}:{component['version']}")

                # Finally upload the dependencies.yaml file into the target registry 
                targetRegistryClient.oras_push(dependencies_file_path, _DEPENDENCIES_YAML_LOCATION, edge_version, dryrun=dryrun)

            _logger.info(f"======= Successfully copied dependencies of Cumulocity Edge version '{edge_version}' from the source registry '{source_registry}' into the target registry '{target_registry}'.")
        except:
            _logger.exception("", exc_info=True)

            _logger.info(f"======= Failed to copy dependencies of Cumulocity Edge version '{edge_version}' from the source registry '{source_registry}' into the target registry '{target_registry}'.")

        return

class RegistryClient():
    def __init__(self, hostname, username, password, tmpDirectory):
        self.hostname = hostname
        self.username = username
        self.password = password
        self.tmpDirectory = tmpDirectory

    def create_harbor_projects(self, dryrun :bool):
        # Fetch existing projects
        try:
            projects_response = None
            projects_response = requests.Session().get(
                f"https://{self.hostname}/api/v2.0/projects", 
                auth=HTTPBasicAuth(self.username, self.password), 
                verify=False)
            projects_response.raise_for_status()
            existing_projects = [project["name"] for project in projects_response.json()]
        except Exception:
            message = "Error fetching the existing projects from the target registry."
            if projects_response:
                message += f"\nResponse Body: {projects_response.json()}"

            _logger.error(message, exc_info=False)
            raise Exception(message)

        for project in ['edge', 'edge-thirdparty', 'microservice-hosting', 'stack', 'thin-edge', 'cdh']:
            if project not in existing_projects:
                if not dryrun:
                    try:
                        create_project_response = None
                        create_project_payload = {
                            "project_name": project,
                        }
                        create_project_response = requests.Session().post(
                            f"https://{self.hostname}/api/v2.0/projects", 
                            headers={'Content-Type':'application/json'},
                            auth=HTTPBasicAuth(self.username, self.password),
                            json=create_project_payload,
                            verify=False)
                        create_project_response.raise_for_status()
                    except Exception:
                        message = f"Error creating the project '{project}' in the target registry."
                        if create_project_response:
                            message += f"\nResponse Body: {create_project_response.json()}"

                        _logger.error(message, exc_info=False)
                        raise Exception(message)
                    
                _logger.info(f"Created the project '{project}' in the target registry.")
            else:
                _logger.info(f"Skipped creating the project '{project}' as it already exists in the target registry.")

    def oras_pull(self, repo :str, tag :str, dryrun :bool) -> str:
        if self.username and self.password:
            pull_command = f'echo "{self.password}" | oras pull -u "{self.username}" --password-stdin {self.hostname}/{repo}:{tag}'
        else:
            pull_command = f'oras pull {self.hostname}/{repo}:{tag}'

        response = self._execute(pull_command, cwd=self.tmpDirectory, dryrun=dryrun)
        if response['returnCode'] == 0:
            downloaded_file_path = os.path.join(self.tmpDirectory, os.path.basename(repo))
            _logger.debug(f"Successfully pulled '{repo}:{tag}' from registry '{self.hostname}' into file '{downloaded_file_path}'.")
            return downloaded_file_path
        else:
            message = f"Failed to pull '{repo}:{tag}' from registry '{self.hostname}'.\n{response['stdout']}"
            _logger.error(message, exc_info=False)
            raise Exception(message)

    def oras_push(self, file_path :str, repo :str, tag :str, dryrun :bool):
        if self.username and self.password:
            push_command = f'echo "{self.password}" | oras push -u "{self.username}" --password-stdin {self.hostname}/{repo}:{tag} {os.path.basename(file_path)}'
        else:
            push_command = f'oras push {self.hostname}/{repo}:{tag} {os.path.basename(file_path)}'

        response = self._execute(push_command, cwd=os.path.dirname(file_path), dryrun=dryrun)
        if response['returnCode'] == 0:
            _logger.debug(f"Successfully pushed oras file '{file_path}' into repo '{repo}:{tag}' of registry '{self.hostname}'.")
        else:
            message = f"Failed to push oras file '{file_path}' into repo '{repo}:{tag}' of registry '{self.hostname}'.\n{response['stdout']}"
            _logger.error(message, exc_info=False)
            raise Exception(message)
            
    def docker_pull(self, repo :str, tag :str, dryrun :bool) -> str:
        source_image = f"{self.hostname}/{repo}:{tag}"

        commands = self._prepare_commands(
            [
                f'echo "{self.password}" | docker login {self.hostname} -u "{self.username}" --password-stdin'
            ],
            [
                f"docker pull {source_image}", # Pull image from source repository
            ]
        )

        response = self._execute(" && ".join(commands), dryrun=dryrun)
        if response['returnCode'] == 0:
            _logger.debug(f"Successfully pulled docker image '{repo}:{tag}' from registry '{self.hostname}'.")
            return source_image
        else:
            message = f"Failed to pull docker image '{repo}:{tag}' from registry '{self.hostname}'.\n{response['stdout']}"
            _logger.error(message, exc_info=False)
            raise Exception(message)

    def docker_push(self, source_image, repo :str, tag :str, dryrun :bool):
        target_image = f"{self.hostname}/{repo}:{tag}"

        commands = self._prepare_commands(
            [
                f'echo "{self.password}" | docker login {self.hostname} -u "{self.username}" --password-stdin',
            ],
            [
                f"docker tag {source_image} {target_image}", # Move to target repository on local 
                f"docker push {target_image}" # Push image to target repository on remote
            ]
        )
        
        response = self._execute(" && ".join(commands), dryrun=dryrun)
        if response['returnCode'] == 0:
            _logger.debug(f"Successfully pushed docker image '{repo}:{tag}' into registry '{self.hostname}'.")
        else:
            message = f"Failed to push docker image '{repo}:{tag}' into registry '{self.hostname}'.\n{response['stdout']}"
            _logger.error(message, exc_info=False)
            raise Exception(message)

    def chart_pull(self, repo :str, chart_name :str, tag :str, dryrun :bool) -> str:
        commands = self._prepare_commands(
            [
                f'echo "{self.password}" | helm registry login --username "{self.username}" --password-stdin {self.hostname}', 
            ],
            [
                f"helm pull oci://{self.hostname}/{repo}/{chart_name} --version {tag}",  # Pull chart from source repository as an oci artifact
            ]
        )

        response = self._execute(" && ".join(commands), cwd=self.tmpDirectory, dryrun=dryrun)
        if response['returnCode'] == 0:
            _logger.debug(f"Successfully pulled chart '{repo}/{chart_name}:{tag}' from registry '{self.hostname}'.")
            return os.path.join(self.tmpDirectory, f"{chart_name}-{tag}.tgz")
        else:
            message = f"Failed to pull chart '{repo}/{chart_name}:{tag}' from registry '{self.hostname}'.\n{response['stdout']}"
            _logger.error(message, exc_info=False)
            raise Exception(message)

    def chart_pull_http(self, repo_url :str, chart_name :str, tag :str, dryrun :bool) -> str:
        commands = self._prepare_commands(
            [
                f'echo "{self.password}" | helm registry login --username "{self.username}" --password-stdin {self.hostname}', 
            ],
            [
                f"helm pull {repo_url}",  # Pull chart from source repository
            ]
        )

        response = self._execute(" && ".join(commands), cwd=self.tmpDirectory, dryrun=dryrun)
        if response['returnCode'] == 0:
            _logger.debug(f"Successfully pulled chart '{chart_name}:{tag}' from repository '{repo_url}'.")
            return os.path.join(self.tmpDirectory, f"{chart_name}-{tag}.tgz")
        else:
            message = f"Failed to pull chart '{chart_name}:{tag}' from repository '{repo_url}'.\n{response['stdout']}"
            _logger.error(message, exc_info=False)
            raise Exception(message)

    def chart_push(self, chart_file_path :str, repo :str, dryrun :bool):
        commands = self._prepare_commands(
            [
                f'echo "{self.password}" | helm registry login --username "{self.username}" --password-stdin {self.hostname}', 
            ],
            [
                f"helm push {chart_file_path} oci://{self.hostname}/{repo}" # Push chart to target repository as an oci artifact
            ]
        )

        response = self._execute(" && ".join(commands), dryrun=dryrun)
        if response['returnCode'] == 0:
            _logger.debug(f"Successfully pushed chart '{chart_file_path}' into registry '{self.hostname}'.")
        else:
            message = f"Failed to push chart '{chart_file_path}' into registry '{self.hostname}'.\n{response['stdout']}"
            _logger.error(message, exc_info=False)
            raise Exception(message)

    def _prepare_commands(self, login_commands :List[str], operation_commands :List[str]) -> List[str]:
        if self.username and self.password:
            return login_commands + operation_commands
        
        return operation_commands
    
    def _execute(self, cmd, cwd=None, shell=True, dryrun=False):
        """
        Executes the given command and returns the exit code.
        Returns 0 if the command execution is successful
        Returns non-zero, when the command execution competed with non-zero exit code or command execution time out.
        """
        try:
            _logger.debug(f"Command execution begin: {self._mask_sensitive_words(cmd)}")
            if not dryrun:
                result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, cwd=cwd, shell=shell, check=True)
                returnValue = {"returnCode": result.returncode, "stdout": result.stdout.decode()} 
            else:
                returnValue = {"returnCode": 0, "stdout": ""} 

        except subprocess.CalledProcessError as err:
            _logger.exception(f'Subprocess exited with exit code: {err.returncode}, Error: {self._mask_sensitive_words(err.output)}')
            returnValue = {"returnCode": err.returncode, "stdout": self._mask_sensitive_words(err.stdout.decode())} 
        except subprocess.TimeoutExpired as err:
            _logger.exception(f'Subprocess timeout.')
            returnValue = {"returnCode": 1, "stdout": self._mask_sensitive_words(err.stdout.decode())}  #There is no specific return-code incase of timeout returned here hence using 1 as return code, in general linux uses exitcode 124
        except Exception as err:
            _logger.exception(f'Command execution failed.')
            returnValue = {"returnCode": 1, "stdout": None} 
        finally:
            if returnValue['stdout']:
                _logger.debug(f"Command execution's standard output follows... \n{self._mask_sensitive_words(returnValue['stdout'])}")
            else:
                _logger.debug(f"Command execution's standard output follows... \nNONE")

            _logger.debug(f"Command execution end: {self._mask_sensitive_words(cmd)}")

        return returnValue
    
    def _mask_sensitive_words(self, text):
        if not self.password:
            return text
        
        # Constructing regex pattern to match any of the sensitive words
        pattern = re.compile('|'.join(re.escape(word) for word in [self.password]), re.IGNORECASE)

        # Replace sensitive words with asterisks
        masked_text = pattern.sub('****', str(text))

        return masked_text

def main():
    RegistrySync(*sys.argv)

if __name__ == "__main__":
    main()

